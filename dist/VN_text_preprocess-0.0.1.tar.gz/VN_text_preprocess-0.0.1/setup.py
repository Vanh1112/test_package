import setuptools

setuptools.setup(
    name="VN_text_preprocess",
    version="0.0.1",
    author="Vanhnee",
    author_email="phamvananh11150348@gmail.com",
    description="Sort description",
    long_description="Full description",
    long_description_content_type="text/markdown",
    url="https://github.com/pypa/sampleproject",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
